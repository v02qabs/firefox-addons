curl https://code.jquery.com/jquery-3.4.1.min.js -o jquery.js
