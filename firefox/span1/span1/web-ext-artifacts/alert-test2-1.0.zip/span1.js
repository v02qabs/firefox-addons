$(function()
	{
		$(function()
			{
				alert("Hello.");
			}
		);
	});

